Thank you for buying Colorful, I hope it'll fit your needs ! Full documentation is available in the Help menu.

If you have any questions or feedback, you can contact me at :

	* E-mail: thomas.hourdel@gmail.com
	* Twitter: @Chman
	* Unity Community: http://forum.unity3d.com/members/15388-Chman

Quick links :

	* Asset Store: https://www.assetstore.unity3d.com/#/content/3842
	* Itch.io : http://chman.itch.io/colorful
	* Forum : http://forum.unity3d.com/threads/143417-Colorful-Post-FX-amp-Photoshop-like-Color-Correction-tools
	* Online Documentation : http://www.thomashourdel.com/colorful/doc
