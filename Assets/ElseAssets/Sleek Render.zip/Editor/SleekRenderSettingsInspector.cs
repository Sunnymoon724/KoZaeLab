﻿using System;
using System.Linq.Expressions;
using UnityEditor;
using UnityEngine;

namespace SleekRender
{
    [CustomEditor(typeof(SleekRenderSettings))]
    public class SleekRenderSettingsInspector : Editor
    {
        private SerializedProperty _isBloomGroupExpandedProperty;
        private SerializedProperty _bloomEnabledProperty;
        private SerializedProperty _bloomThresholdProperty;
        private SerializedProperty _bloomIntensityProperty;
        private SerializedProperty _bloomTintProperty;
        private SerializedProperty _bloomPreserveAspectRatioProperty;
        private SerializedProperty _bloomTextureWidth;
        private SerializedProperty _bloomTextureHeight;
        private SerializedProperty _bloomPassCountProperty;
        private SerializedProperty _bloomLumaVectorProperty;
        private SerializedProperty _bloomSelectedLumaVectorTypeProperty;

        private string[] _bloomPassCountVariants = new[] { "3", "5" };
        private int[] _bloomPassCountVariantInts = new[] { 3, 5 };
        private int _selectedBloomPassCountIndex = -1;

        private LumaVectorType _selectedLumaVectorType;

        private SerializedProperty _isColorizeGroupExpandedProperty;
        private SerializedProperty _colorizeEnabledProperty;
        private SerializedProperty _colorizeProperty;
        private SerializedProperty _colorizeTexProperty;
		private SerializedProperty _colorizeDefaultTexProperty;
        private SerializedProperty _colorizeAmountProperty;

        private SerializedProperty _isVignetteExpandedProperty;
        private SerializedProperty _vignetteEnabledProperty;
        private SerializedProperty _vignetteBeginRadiusProperty;
        private SerializedProperty _vignetteExpandRadiusProperty;
        private SerializedProperty _vignetteColorProperty;

        private SerializedProperty _isContrastAndBrightnessEditorExpandedProperty;
        private SerializedProperty _contrastAndBrightnessEnabledProperty;
        private SerializedProperty _contrasteIntensity;
        private SerializedProperty _brightnesseIntensity;


		private SerializedProperty _isGrayScaleGroupExpandedProperty;
		private SerializedProperty _grayScaleEnabledProperty;
		private SerializedProperty _grayScaleRedLuminaceProperty;
		private SerializedProperty _grayScaleGreenLuminaceProperty;
		private SerializedProperty _grayScaleBlueLuminaceProperty;
		private SerializedProperty _grayScaleAmountProperty;

		private SerializedProperty _isPhotoFilterGroupExpandedProperty;
		private SerializedProperty _photoFilterEnabledProperty;
		private SerializedProperty _photoFilterColorProperty;
		private SerializedProperty _photoFilterdensityProperty;

		private SerializedProperty _isVintageGroupExpandedProperty;
		private SerializedProperty _vintageEnabledProperty;
		//private SerializedProperty _vintageTexProperty;
		private SerializedProperty _vintageAmountProperty;
		private SerializedProperty _vintageFilterProperty;



		int selectedPreset = 0;

		static string[] presets = { "Warming Filter (85)", "Warming Filter (LBA)", "Warming Filter (81)",
								"Cooling Filter (80)", "Cooling Filter (LBB)", "Cooling Filter (82)",
								"Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Violet", "Magenta",
								"Sepia", "Deep Red", "Deep Blue", "Deep Emerald", "Deep Yellow", "Underwater" };

		static float[,] presetsData = { { 0.925f, 0.541f, 0.0f }, { 0.98f, 0.541f, 0.0f }, { 0.922f, 0.694f, 0.075f },
									 { 0.0f, 0.427f, 1.0f }, { 0.0f, 0.365f, 1.0f }, { 0.0f, 0.71f, 1.0f },
									 { 0.918f, 0.102f, 0.102f }, { 0.956f, 0.518f, 0.09f }, { 0.976f, 0.89f, 0.11f },
									 { 0.098f, 0.788f, 0.098f }, { 0.114f, 0.796f, 0.918f }, { 0.114f, 0.209f, 0.918f },
									 { 0.608f, 0.114f, 0.918f }, { 0.89f, 0.094f, 0.89f }, { 0.675f, 0.478f, 0.2f },
									 { 1.0f, 0.0f, 0.0f }, { 0.0f, 0.133f, 0.804f }, { 0.0f, 0.553f, 0.0f },
									 { 1.0f, 0.835f, 0.0f }, { 0.0f, 0.761f, 0.694f } };

		private void OnEnable()
        {
            SetupBloomProperties();

			
			_isColorizeGroupExpandedProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.colorizeExpanded));
            _colorizeEnabledProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.colorizeEnabled));
            _colorizeProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.colorize));
            _colorizeTexProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.LookupTexture));
			_colorizeDefaultTexProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.DefalutLookupTexture));
			_colorizeAmountProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.Amount));

            _isVignetteExpandedProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.vignetteExpanded));
            _vignetteEnabledProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.vignetteEnabled));
            _vignetteBeginRadiusProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.vignetteBeginRadius));
            _vignetteExpandRadiusProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.vignetteExpandRadius));
            _vignetteColorProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.vignetteColor));

            _isContrastAndBrightnessEditorExpandedProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.brightnessContrastExpanded));
            _contrastAndBrightnessEnabledProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.brightnessContrastEnabled));
            _contrasteIntensity = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.contrast));
            _brightnesseIntensity = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.brightness));


			_isGrayScaleGroupExpandedProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.grayScaleExpanded));
			_grayScaleEnabledProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.grayScaleEnabled));
			_grayScaleRedLuminaceProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.grayScaleRedLuminance));
			_grayScaleGreenLuminaceProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.grayScaleGreenLuminance));
			_grayScaleBlueLuminaceProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.grayScaleBlueLuminance));
			_grayScaleAmountProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.grayScaleAmount));


			_isPhotoFilterGroupExpandedProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.photoFilterExpanded));
			_photoFilterEnabledProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.photoFilterEnabled));
			_photoFilterColorProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.photoFilterColor));
			_photoFilterdensityProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.photoFilterDensity));

			_isVintageGroupExpandedProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.vintageExpanded));
			_vintageEnabledProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.vintageEnabled));
			//_vintageTexProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.vin));
			_vintageAmountProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.vintageAmount));
			_vintageFilterProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.vintageFilter));

		}

		private void SetupBloomProperties()
        {
            _isBloomGroupExpandedProperty =
                serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.bloomExpanded));
            _bloomEnabledProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.bloomEnabled));
            _bloomThresholdProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.bloomThreshold));
            _bloomIntensityProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.bloomIntensity));
            _bloomTintProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.bloomTint));

            _bloomPreserveAspectRatioProperty =
                serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.preserveAspectRatio));

            _bloomTextureWidth = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.bloomTextureWidth));
            _bloomTextureHeight =
                serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.bloomTextureHeight));

            _bloomPassCountProperty = serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.bloomPasses));
            _selectedBloomPassCountIndex = Array.IndexOf(_bloomPassCountVariantInts, _bloomPassCountProperty.intValue);

            _bloomLumaVectorProperty =
                serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.bloomLumaVector));
            _bloomSelectedLumaVectorTypeProperty =
                serializedObject.FindProperty(GetMemberName((SleekRenderSettings s) => s.bloomLumaCalculationType));
            _selectedLumaVectorType = (LumaVectorType)_bloomSelectedLumaVectorTypeProperty.enumValueIndex;
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();

            int indent = EditorGUI.indentLevel;

            DrawBloomEditor();
            EditorGUILayout.Space();

            DrawColorizeEditor();
            EditorGUILayout.Space();

            DrawVignetteEditor();
            EditorGUILayout.Space();

            DrawContrastAndBrightnessEditor();
			EditorGUILayout.Space();

			DrawGrayScaleEditor();
			EditorGUILayout.Space();

			DrawPhotoFilterEditor();
			EditorGUILayout.Space();

			DrawVintageEditor();

			DrawTotalCost();

            EditorGUI.indentLevel = indent;
            serializedObject.ApplyModifiedProperties();
        }

        private void DrawContrastAndBrightnessEditor()
        {
            Header("Brightness / Contrast", _isContrastAndBrightnessEditorExpandedProperty, _contrastAndBrightnessEnabledProperty);

            if (_isContrastAndBrightnessEditorExpandedProperty.boolValue)
            {
                EditorGUI.indentLevel += 1;

                EditorGUILayout.LabelField("Contrast Intensity");
                EditorGUILayout.Slider(_contrasteIntensity, -1f, 1f, "");

                EditorGUILayout.LabelField("Brightness Intensity");
                EditorGUILayout.Slider(_brightnesseIntensity, -1f, 1f, "");

                EditorGUI.indentLevel -= 1;
            }
        }

        private void DrawVignetteEditor()
        {
            Header("Vignette", _isVignetteExpandedProperty, _vignetteEnabledProperty);

            if (_isVignetteExpandedProperty.boolValue)
            {
                EditorGUI.indentLevel += 1;

                EditorGUILayout.LabelField("Begin radius");
                EditorGUILayout.Slider(_vignetteBeginRadiusProperty, 0f, 1f, "");

                EditorGUILayout.LabelField("Expand radius");
                EditorGUILayout.Slider(_vignetteExpandRadiusProperty, 0f, 3f, "");

                EditorGUILayout.LabelField("Color");
                _vignetteColorProperty.colorValue = EditorGUILayout.ColorField("", _vignetteColorProperty.colorValue);

                EditorGUI.indentLevel -= 1;
            }
        }

        private void DrawColorizeEditor()
        {
            Header("Colorize", _isColorizeGroupExpandedProperty, _colorizeEnabledProperty);

            if (_isColorizeGroupExpandedProperty.boolValue)
            {
                EditorGUI.indentLevel += 1;

                EditorGUILayout.LabelField("Color");
                _colorizeProperty.colorValue = EditorGUILayout.ColorField("", _colorizeProperty.colorValue);

                EditorGUILayout.LabelField("Amount");
                EditorGUILayout.Slider(_colorizeAmountProperty, 0f, 1f, "");

                //EditorGUILayout.LabelField("lut Texture");
                EditorGUILayout.PropertyField(_colorizeTexProperty);
				EditorGUILayout.PropertyField(_colorizeDefaultTexProperty);
                serializedObject.ApplyModifiedProperties();

                //EditorGUILayout.HelpBox("Note: Lookup Texture chanage", MessageType.Info);

                EditorGUI.indentLevel -= 1;
            }
        }

        private void DrawBloomEditor()
        {
            Header("Bloom", _isBloomGroupExpandedProperty, _bloomEnabledProperty);

            if (_isBloomGroupExpandedProperty.boolValue)
            {
                EditorGUI.indentLevel += 1;

                EditorGUILayout.LabelField("Bloom threshold");
                EditorGUILayout.Slider(_bloomThresholdProperty, -1.0f, 1f, "");
                EditorGUILayout.LabelField("Bloom intensity");
                EditorGUILayout.Slider(_bloomIntensityProperty, 0f, 15f, "");
                EditorGUILayout.LabelField("Bloom tint");
                _bloomTintProperty.colorValue = EditorGUILayout.ColorField("", _bloomTintProperty.colorValue);

                DrawCommonBloomParameters();
                DrawDualFilterBloomTextureSizeSettings();

                DisplayLumaVectorProperties();

                EditorGUI.indentLevel -= 1;
            }
        }

        private void DrawCommonBloomParameters()
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Bloom texture size");

            _bloomPreserveAspectRatioProperty.boolValue = EditorGUILayout.ToggleLeft("Preserve aspect ratio", _bloomPreserveAspectRatioProperty.boolValue);

            if (!_bloomPreserveAspectRatioProperty.boolValue)
            {
                EditorGUILayout.IntSlider(_bloomTextureWidth, 32, 164, "X");
            }

            EditorGUILayout.IntSlider(_bloomTextureHeight, 32, 164, "Y");
        }

        private void DrawDualFilterBloomTextureSizeSettings()
        {
            EditorGUILayout.Space();
            var bloomPassesControlRect = EditorGUILayout.GetControlRect();
            var bloomPassesLabelRect = new Rect(bloomPassesControlRect.x, bloomPassesControlRect.y,
                bloomPassesControlRect.width * 0.5f, bloomPassesControlRect.height);
            var bloomPassesPopupRect = new Rect(bloomPassesControlRect.x + bloomPassesLabelRect.width, bloomPassesControlRect.y,
                bloomPassesControlRect.width * 0.5f, bloomPassesControlRect.height);

            EditorGUI.LabelField(bloomPassesLabelRect, "Bloom passes");

            _selectedBloomPassCountIndex = _selectedBloomPassCountIndex != -1 ? _selectedBloomPassCountIndex : 1;
            _selectedBloomPassCountIndex = EditorGUI.Popup(bloomPassesPopupRect, _selectedBloomPassCountIndex, _bloomPassCountVariants);
            _bloomPassCountProperty.intValue = _bloomPassCountVariantInts[_selectedBloomPassCountIndex];
        }

        private void DisplayLumaVectorProperties()
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Brightpass Luma calculation");

            _selectedLumaVectorType = (LumaVectorType)EditorGUILayout.EnumPopup(_selectedLumaVectorType);
            _bloomSelectedLumaVectorTypeProperty.enumValueIndex = (int)_selectedLumaVectorType;
            switch (_selectedLumaVectorType)
            {
                case LumaVectorType.Custom:
                    EditorGUILayout.PropertyField(_bloomLumaVectorProperty, new GUIContent(""));
                    break;
                case LumaVectorType.Uniform:
                    var oneOverThree = 1f / 3f;
                    _bloomLumaVectorProperty.vector3Value = new Vector3(oneOverThree, oneOverThree, oneOverThree);
                    break;
                case LumaVectorType.sRGB:
                    _bloomLumaVectorProperty.vector3Value = new Vector3(0.2126f, 0.7152f, 0.0722f);
                    break;
            }

            var vector = _bloomLumaVectorProperty.vector3Value;
            if (!Mathf.Approximately(vector.x + vector.y + vector.z, 1f))
            {
                EditorGUILayout.HelpBox("Luma vector is not normalized.\nVector values should sum up to 1.",
                    MessageType.Warning);
            }
        }

        private void DrawTotalCost()
        {
            EditorGUILayout.LabelField("", GUI.skin.horizontalSlider);
            EditorGUILayout.HelpBox(SleekRenderCostCalculator.GetTotalCostStringFor(target as SleekRenderSettings),
                MessageType.Info);
        }
		private void DrawGrayScaleEditor()
		{
			Header("GrayScale", _isGrayScaleGroupExpandedProperty, _grayScaleEnabledProperty);
			if (_isGrayScaleGroupExpandedProperty.boolValue)
			{
				EditorGUI.indentLevel += 1;

				EditorGUILayout.LabelField("RedLumiance");
				EditorGUILayout.Slider(_grayScaleRedLuminaceProperty, 0f, 1f, "");
				EditorGUILayout.LabelField("GreenLumiance");
				EditorGUILayout.Slider(_grayScaleGreenLuminaceProperty, 0f, 1f, "");
				EditorGUILayout.LabelField("BlueLumiance");
				EditorGUILayout.Slider(_grayScaleBlueLuminaceProperty, 0f, 1f, "");
				EditorGUILayout.LabelField("Amount");
				EditorGUILayout.Slider(_grayScaleAmountProperty, 0f, 1f, "");

				EditorGUI.indentLevel -= 1;
			}
		}
		private void DrawPhotoFilterEditor()
        {
            Header("PhotoFilter", _isPhotoFilterGroupExpandedProperty, _photoFilterEnabledProperty);

            if (_isPhotoFilterGroupExpandedProperty.boolValue)
            {
                EditorGUI.indentLevel += 1;

                EditorGUILayout.LabelField("Color");
				_photoFilterColorProperty.colorValue = EditorGUILayout.ColorField("", _photoFilterColorProperty.colorValue);

				GUI.changed = false;
				selectedPreset = EditorGUILayout.Popup("Preset", selectedPreset, presets);

				if (GUI.changed)
				{
					_photoFilterColorProperty.colorValue = new Color(
							presetsData[selectedPreset, 0],
							presetsData[selectedPreset, 1],
							presetsData[selectedPreset, 2],
							1.0f
						);
				}
				//_photoFilterColorProperty.colorValue = EditorGUILayout.ColorField("", _bloomTintProperty.colorValue);
				EditorGUILayout.LabelField("Density");
                EditorGUILayout.Slider(_photoFilterdensityProperty, 0f, 1f, "");

                EditorGUI.indentLevel -= 1;
            }
        }
		private void DrawVintageEditor()
		{
			Header("Vintage", _isVintageGroupExpandedProperty, _vintageEnabledProperty);

			if (_isVintageGroupExpandedProperty.boolValue)
			{
				EditorGUI.indentLevel += 1;

				//EditorGUILayout.PropertyField(_vintageTexProperty);
				EditorGUILayout.PropertyField(_vintageFilterProperty);
				EditorGUILayout.PropertyField(_vintageAmountProperty);
				EditorGUI.indentLevel -= 1;
			}
		}
		//private void DrawPhotoFilter()
		//{
		//	EditorGUILayout.PropertyField(_PhotoFiltercolor);
		//	EditorGUILayout.PropertyField(_pPhotoFilterdensity);
		//}

		public static bool Header(string title, SerializedProperty isExpanded, SerializedProperty enabledField)
        {
            var display = isExpanded == null || isExpanded.boolValue;
            var enabled = enabledField.boolValue;
            var rect = GUILayoutUtility.GetRect(16f, 22f, FxStyles.header);
            GUI.Box(rect, title, FxStyles.header);

            var toggleRect = new Rect(rect.x + 4f, rect.y + 4f, 13f, 13f);
            var e = Event.current;

            if (e.type == EventType.Repaint)
            {
                FxStyles.headerCheckbox.Draw(toggleRect, false, false, enabled, false);
            }

            if (e.type == EventType.MouseDown)
            {
                const float kOffset = 2f;
                toggleRect.x -= kOffset;
                toggleRect.y -= kOffset;
                toggleRect.width += kOffset * 2f;
                toggleRect.height += kOffset * 2f;

                if (toggleRect.Contains(e.mousePosition))
                {
                    enabledField.boolValue = !enabledField.boolValue;
                    e.Use();
                }
                else if (rect.Contains(e.mousePosition) && isExpanded != null)
                {
                    display = !display;
                    isExpanded.boolValue = !isExpanded.boolValue;
                    e.Use();
                }
            }

            return display;
        }

        public static string GetMemberName<T, TValue>(Expression<Func<T, TValue>> memberAccess)
        {
            return ((MemberExpression)memberAccess.Body).Member.Name;
        }
    }
}