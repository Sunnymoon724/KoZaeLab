﻿using System;
using UnityEngine;

namespace SleekRender
{
	public enum VintageFilter
	{
		None,
		F1977,
		Aden,
		Amaro,
		Brannan,
		Crema,
		Earlybird,
		Hefe,
		Hudson,
		Inkwell,
		Juno,
		Kelvin,
		Lark,
		LoFi,
		Ludwig,
		Mayfair,
		Nashville,
		Perpetua,
		Reyes,
		Rise,
		Sierra,
		Slumber,
		Sutro,
		Toaster,
		Valencia,
		Walden,
		Willow,
		XProII
	}

	[CreateAssetMenu(menuName = "Sleek Render Settings")]
    [Serializable]
    public class SleekRenderSettings : ScriptableObject
    {
        [Header("Bloom")]
        public bool bloomExpanded = false;
        public bool bloomEnabled = false;
        public float bloomThreshold = 0.6f;
        public float bloomIntensity = 2.5f;
        public Color bloomTint = Color.white;

        public bool preserveAspectRatio = true;
        public int bloomPasses = 5;
        public int bloomTextureWidth = 128;
        public int bloomTextureHeight = 128;

        public LumaVectorType bloomLumaCalculationType = LumaVectorType.Uniform;
        public Vector3 bloomLumaVector = new Vector3(1f / 3f, 1f / 3f, 1f / 3f);

        [Header("Color overlay (alpha sets intensity)")]
        public bool colorizeExpanded = true;
        public bool colorizeEnabled = false;

		// Warm sepia by default
		[Header("LUT Color Grading")]
		public Color32 colorize = new Color32(246, 176, 114, 100);
        public Texture2D LookupTexture;
		public Texture2D DefalutLookupTexture;
        public float Amount = 1.0f;
		public float fLerpBlend;
		public bool bColorBlend = false;

		[Header("Vignette")]
        public bool vignetteExpanded = true;
        public bool vignetteEnabled = false;

        public float vignetteBeginRadius = 0.166f;
        public float vignetteExpandRadius = 1.34f;
        public Color vignetteColor = Color.black;

        [Header("Contrast/Brightness")]
        public bool brightnessContrastExpanded = false;
        public bool brightnessContrastEnabled = false;

        public float contrast = 0f;
        public float brightness = 0f;

		[Header("GrayScale")]

		public bool grayScaleExpanded = false;
		public bool grayScaleEnabled = false;

		public float grayScaleRedLuminance = 0.333f;
		public float grayScaleGreenLuminance = 0.334f;
		public float grayScaleBlueLuminance = 0.114f;
		public float grayScaleAmount = 1.0f;

		[Header("PhotoFilter")]

		public bool photoFilterExpanded = false;
		public bool photoFilterEnabled = false;

		public Color photoFilterColor = new Color(1.0f, 0.5f, 0.2f, 1.0f);
		public float photoFilterDensity = 0.35f;

		[Header("Vintage")]

		public bool vintageExpanded = false;
		public bool vintageEnabled = false;

		//public Texture vintageLookupTexture;
		public VintageFilter vintageFilter = VintageFilter.None;
		public float vintageAmount = 1f;
		//public float photoFilterPresetData = 
	}

    public enum LumaVectorType
    {
        Uniform,
        sRGB,
        Custom
    }
}