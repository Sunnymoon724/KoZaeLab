﻿using System;
using UnityEngine;
using UnityEngine.Rendering;
//using System.Diagnostics;

namespace SleekRender
{
	// Custom component editor view definition
	[AddComponentMenu("Effects/Sleek Render Post Process")]
	[RequireComponent(typeof(Camera))]
	[ExecuteInEditMode, DisallowMultipleComponent]
	public class SleekRenderPostProcess : MonoBehaviour
	{
		// Keywords for shader variants
		private static class Keywords
		{
			public const string COLORIZE_ON = "COLORIZE_ON";
			public const string BLOOM_ON = "BLOOM_ON";
			public const string VIGNETTE_ON = "VIGNETTE_ON";
			public const string BRIGHTNESS_CONTRAST_ON = "BRIGHTNESS_CONTRAST_ON";
			public const string GRAYSCALE_ON = "GRAYSCALE_ON";
			public const string PHOTOFILTER_ON = "PHOTOFILTER_ON";
			public const string VINTAGE_ON = "VINTAGE_ON";
            //public const string DOF_ON = "DOF_ON";
			//public const string LUTCOLORBLEND_ON = "LUTCOLORBLEND_ON";
		}

		// Currently linked settings in the inspector
		public SleekRenderSettings settings;

		// Various Material cached objects
		// Created dynamically from found and loaded shaders
		private Material _preComposeMaterial;
		private Material _composeMaterial;

		private PassRenderer _passRenderer;
		private DualFilterBloomRenderer _bloomRenderer;

		private RenderTexture _preComposeTexture;
		private RenderTexture _bloomResultTexture;

		//public Texture2D LookupTexture;
		private Texture2D previousTexture;

		private Texture vintageLookupTexture;

		private Material _lutMaterial;
		private Texture3D _converted3DLut = null;
		private Texture3D _prevConverted3DLut = null; //최초 로딩 시 Default로 처리하자.
		//private Texture3D _defalutCoverted3DLut = null; //최초 로딩 시 Default로 처리하자.

		private int lutSize;
		//public float Amount = 1.0f;

		// Currenly cached camera on which Post Processing stack is applied
		private Camera _mainCamera;

		// Cached camera width and height. Used in editor code for checking updated size for recreating resources
		private int _currentCameraPixelWidth;
		private int _currentCameraPixelHeight;

		// Various cached variables needed to avoid excessive shader enabling / disabling
		private bool _isColorizeAlreadyEnabled = false;
		private bool _isBloomAlreadyEnabled = false;
		private bool _isVignetteAlreadyEnabled = false;
		private bool _isContrastAndBrightnessAlreadyEnabled = false;
		private bool _isGrayScaleAlreadyEnabled = false;
		private bool _isPhotoFilterAlreadyEnabled = false;
		private bool _isVintageAlreadyEnabled = false;
		//private bool _isLutColorBlend = false;

		private VintageFilter _currentVintageFilter = VintageFilter.None;

        public Camera MainCamera
        {
            get { return _mainCamera; }
        }

        //private Camera m_depthCamera;
        //private GameObject m_depthCameraObject;
        //private RenderTexture m_depthTexture;

        //private GameObject DepthCameraObject
        //{
        //    get
        //    {
        //        if (!m_depthCameraObject)
        //        {
        //            m_depthCameraObject = new GameObject("depthCameraObject");
        //            m_depthCameraObject.hideFlags = HideFlags.HideAndDontSave;
        //            m_depthCameraObject.AddComponent<Camera>();
        //            DepthCamera.hideFlags = HideFlags.HideAndDontSave;
        //        }
        //        return m_depthCameraObject;
        //    }
        //}

        //private Camera DepthCamera
        //{
        //    get
        //    {
        //        if (m_depthCamera == null)
        //        {
        //            m_depthCamera = DepthCameraObject.GetComponent<Camera>();
        //        }
        //        return m_depthCamera;
        //    }
        //}
        //private void SetupDepthCamera()
        //{
        //    DepthCamera.CopyFrom(GetComponent<Camera>());
        //    DepthCamera.allowMSAA = false;

        //    DepthCamera.targetTexture = m_depthTexture;

        //    DepthCamera.enabled = false;

        //}


        private void OnEnable()
		{
			// If we are adding a component from scratch, we should supply fake settings with default values 
			// (until normal ones are linked)
			CreateDefaultSettingsIfNoneLinked();
			CreateResources();
			SetIdentityLut();
		}

		private void OnDisable()
		{
			ReleaseResources();
			ReleaseIdentityLut();
		}

        public void ChangeLutTexture()
        {
            if (settings.LookupTexture == null)
                return;

            Convert(settings.LookupTexture);
            previousTexture = settings.LookupTexture;
        }

        //private void checkChangeLUT() //에디터상에서 실시간 체크를 한다.
        //{
        //    ChangeLutTexture();
        //}

		private void OnRenderImage(RenderTexture source, RenderTexture target)
		{
            //if (settings.colorizeEnabled && settings.LookupTexture != previousTexture)
            //{
            //	Convert(settings.LookupTexture);
            //             //if(previousTexture != null)
            //             //{
            //             //    DestroyImmediate(previousTexture);
            //             //    previousTexture = null;
            //             //}
            //             previousTexture = settings.LookupTexture;

            //}
            // Editor only behaviour needed to apply stub settings if none linked yet
#if UNITY_EDITOR
            ChangeLutTexture();
            CreateDefaultSettingsIfNoneLinked();
#endif
            //if (SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.Depth))
            //{
            //    m_depthTexture = RenderTexture.GetTemporary(source.width / 2, source.height / 2, 24, RenderTextureFormat.Depth);
            //    SetupDepthCamera();
            //    DepthCamera.Render();
            //    Shader.SetGlobalTexture("_CameraDepthTexture", m_depthTexture);
            //    RenderTexture.ReleaseTemporary(m_depthTexture);
            //}
            
            CheckSetupChangeAndRecreateResourcesIfNeeded(_mainCamera);
			// Applying post processing steps
			ApplyPostProcess(source);
			// Last step as separate pass
			Compose(source, target);
		}

		private void ApplyPostProcess(RenderTexture source)
		{
			var isBloomEnabled = settings.bloomEnabled;
			Bloom(source, isBloomEnabled);
			Precompose(source, isBloomEnabled);
		}

		private void Bloom(RenderTexture source, bool isBloomEnabled)
		{
			if (isBloomEnabled)
			{
				_bloomResultTexture = _bloomRenderer.ApplyToAndReturn(source, settings);
			}
		}

		private void Precompose(RenderTexture source, bool isBloomEnabled)
		{
			// Setting up vignette effect
			var isVignetteEnabledInSettings = settings.vignetteEnabled;
			if (isVignetteEnabledInSettings && !_isVignetteAlreadyEnabled)
			{
				_preComposeMaterial.EnableKeyword(Keywords.VIGNETTE_ON);
				_isVignetteAlreadyEnabled = true;
			}
			else if (!isVignetteEnabledInSettings && _isVignetteAlreadyEnabled)
			{
				_preComposeMaterial.DisableKeyword(Keywords.VIGNETTE_ON);
				_isVignetteAlreadyEnabled = false;
			}

			if (isVignetteEnabledInSettings)
			{
				// Calculating Vignette parameters once per frame rather than once per pixel
				float vignetteBeginRadius = settings.vignetteBeginRadius;
				float squareVignetteBeginRaduis = vignetteBeginRadius * vignetteBeginRadius;
				float vignetteRadii = vignetteBeginRadius + settings.vignetteExpandRadius;
				float oneOverVignetteRadiusDistance = 1f / (vignetteRadii - squareVignetteBeginRaduis);

				var vignetteColor = settings.vignetteColor;

				_preComposeMaterial.SetVector(Uniforms._VignetteShape, new Vector4(
					4f * oneOverVignetteRadiusDistance * oneOverVignetteRadiusDistance,
					-oneOverVignetteRadiusDistance * squareVignetteBeginRaduis));

				// Premultiplying Alpha of vignette color
				_preComposeMaterial.SetColor(Uniforms._VignetteColor, new Color(
					vignetteColor.r * vignetteColor.a,
					vignetteColor.g * vignetteColor.a,
					vignetteColor.b * vignetteColor.a,
					vignetteColor.a));
			}


			// Bloom is handled in two different passes (two blurring bloom passes and one precompose pass)
			// So we need to check for whether it's enabled in precompose step too (shader has variants without bloom)
			if (isBloomEnabled)
			{
				_preComposeMaterial.SetTexture(Uniforms._BloomTex, _bloomResultTexture);
				_preComposeMaterial.SetFloat(Uniforms._BloomIntencity, settings.bloomIntensity);
				_preComposeMaterial.SetColor(Uniforms._BloomTint, settings.bloomTint);

				if (!_isBloomAlreadyEnabled)
				{
					_preComposeMaterial.EnableKeyword(Keywords.BLOOM_ON);
					_isBloomAlreadyEnabled = true;
				}
			}
			else if (_isBloomAlreadyEnabled)
			{
				_preComposeMaterial.DisableKeyword(Keywords.BLOOM_ON);
				_isBloomAlreadyEnabled = false;
			}

			var sourceRenderTexture = isBloomEnabled ? _bloomResultTexture : source;
			// Finally applying precompose step. It slaps bloom and vignette together
			_passRenderer.Blit(sourceRenderTexture, _preComposeTexture, _preComposeMaterial);
		}
		
		private void ReleaseIdentityLut()
		{
			if (_prevConverted3DLut != null)
			{
				if (_converted3DLut != _prevConverted3DLut)
				{
					DestroyImmediate(_prevConverted3DLut);

				}
				_prevConverted3DLut = null;
			}
			if (_converted3DLut != null)
			{
				DestroyImmediate(_converted3DLut);
			}
			_converted3DLut = null;

            //if (settings.LookupTexture != null)
            //{
            //    DestroyImmediate(settings.LookupTexture);
            //    settings.LookupTexture = null;
            //}
        }
		public void SetIdentityLut()
		{
			
			if (!SystemInfo.supports3DTextures)
			{
				return;
			}
			else
			{
				if (settings.DefalutLookupTexture == null)
				{
#if UNITY_EDITOR
                    settings.DefalutLookupTexture = (Texture2D)UnityEditor.AssetDatabase.LoadAssetAtPath<Texture>("Assets/bundle/postprocess/texture/default_lut.png");
#endif
                }
				if (_converted3DLut != null)
				{
					_converted3DLut.DestroyImmediateIfNotNull();
					_converted3DLut = null;
				}
				if (_prevConverted3DLut != null)
				{
					_prevConverted3DLut.DestroyImmediateIfNotNull();
					_prevConverted3DLut = null;
				}
			}

            if (settings.DefalutLookupTexture == null)
            {
                settings.colorizeEnabled = false;
                return;
            }


			int dim = settings.DefalutLookupTexture.height;
			var c = settings.DefalutLookupTexture.GetPixels();
			var newC =  new Color[c.Length];
			var newDefalutC = new Color[c.Length];
			float oneOverDim = 1.0f / (1.0f * dim - 1.0f);

			for (int i = 0; i < dim; i++)
			{
				for (int j = 0; j < dim; j++)
				{
					for (int k = 0; k < dim; k++)
					{
						newC[i + (j * dim) + (k * dim * dim)] = new Color((i * 1.0f) * oneOverDim, (j * 1.0f) * oneOverDim, (k * 1.0f) * oneOverDim, 1.0f);
						int j_ = dim - j - 1;
						newDefalutC[i + (j * dim) + (k * dim * dim)] = c[k * dim + i + j_ * dim * dim];
					}
				}
			}

			_converted3DLut = new Texture3D(dim, dim, dim, TextureFormat.RGB24, false);
			_converted3DLut.SetPixels(newC);
			_converted3DLut.Apply();
			lutSize = _converted3DLut.width;
			_converted3DLut.wrapMode = TextureWrapMode.Clamp;

			_prevConverted3DLut = new Texture3D(dim, dim, dim, TextureFormat.RGB24, false);
			_prevConverted3DLut.SetPixels(newDefalutC);
			_prevConverted3DLut.Apply();
			_prevConverted3DLut.wrapMode = TextureWrapMode.Clamp;
		}
		public bool ValidDimensions(Texture2D tex2d)
		{
			if (tex2d == null)
			{
				return false;
			}

			int h = tex2d.height;
			if (h != Mathf.FloorToInt(Mathf.Sqrt(tex2d.width)))
			{
				return false;
			}
			return true;
		}
		internal bool Convert(Texture2D lookupTexture)
		{
			if (!SystemInfo.supports3DTextures)
			{
				Debug.LogError("System does not support 3D textures");
				return false;
			}

			if (lookupTexture == null || lookupTexture.mipmapCount > 1)
			{
				Debug.LogError("Lookup texture must not have mipmaps");
				return false;
			}

			if (previousTexture != null)
			{
				if (_prevConverted3DLut != null)
				{
					_prevConverted3DLut.SetPixels(_converted3DLut.GetPixels());
					_prevConverted3DLut.Apply();
					_prevConverted3DLut.wrapMode = TextureWrapMode.Clamp;
				}
			}
			
			
			int dim = lookupTexture.height;

			if (!ValidDimensions(lookupTexture))
			{
				Debug.LogError("Lookup texture dimensions must be a power of two. The height must equal the square root of the width.");
				return false;
			}
			
			var c = lookupTexture.GetPixels();
			var newC = new Color[c.Length];

			for (int i = 0; i < dim; i++)
			{
				for (int j = 0; j < dim; j++)
				{
					for (int k = 0; k < dim; k++)
					{
						int j_ = dim - j - 1;
						newC[i + (j * dim) + (k * dim * dim)] = c[k * dim + i + j_ * dim * dim];
					}
				}
			}
            if(_converted3DLut == null)
            {
                Debug.LogError("_converted3DLut is null");
                return false;
            }
            if (lookupTexture != null)
            {
                if (_converted3DLut != null)
                {
                    _converted3DLut.SetPixels(newC);
                    _converted3DLut.Apply();
                    lutSize = _converted3DLut.width;
                    _converted3DLut.wrapMode = TextureWrapMode.Clamp;
                }
            }

           
			return true;
		}

		private void Compose(RenderTexture source, RenderTexture target)
		{
			//if (_converted3DLut == null)
			//{
			//	SetIdentityLut();
			//}

			// Composing pass includes using full size main render texture + precompose texture
			// Precompose texture contains valuable info in its Alpha channel (whether to apply it on the final image or not)
			// Compose step also includes uniform colorizing which is calculated and enabled / disabled separately


			var isColorizeEnabledInSettings = settings.colorizeEnabled;
			if (isColorizeEnabledInSettings && !_isColorizeAlreadyEnabled)
			{
				if (SystemInfo.supports3DTextures)
				{
					_composeMaterial.EnableKeyword(Keywords.COLORIZE_ON);
					_isColorizeAlreadyEnabled = true;
				}
				else
				{
					isColorizeEnabledInSettings = false;
				}

			}
			else if (!isColorizeEnabledInSettings && _isColorizeAlreadyEnabled)
			{
				_composeMaterial.DisableKeyword(Keywords.COLORIZE_ON);
				_isColorizeAlreadyEnabled = false;
			}

			if (isColorizeEnabledInSettings)
			{
				//var isLutColorBlendInSettings = settings.bColorBlend;
				//if (isLutColorBlendInSettings && !_isLutColorBlend)
				//{
					
				//	_isLutColorBlend = true;
				//}
				//else if (!isLutColorBlendInSettings && _isLutColorBlend)
				//{
				//	_isLutColorBlend = false;
				//}

				Color colorize = settings.colorize;
				var a = colorize.a;
				var colorizeConstant = new Color(colorize.r * a, colorize.g * a, colorize.b * a, 1f - a);

				_composeMaterial.SetColor(Uniforms._Colorize, colorizeConstant);
				_composeMaterial.SetTexture("_ClutTex", _converted3DLut);
				//if (previousTexture == null)
				//{
				//	if (_composeMaterial.IsKeywordEnabled(Keywords.LUTCOLORBLEND_ON))
				//		_composeMaterial.DisableKeyword(Keywords.LUTCOLORBLEND_ON);
				//}
				//else
				//{
				//	if (!_composeMaterial.IsKeywordEnabled(Keywords.LUTCOLORBLEND_ON))
				//		_composeMaterial.EnableKeyword(Keywords.LUTCOLORBLEND_ON);
				//}
				_composeMaterial.SetTexture("_PrevClutTex", _prevConverted3DLut);
				_composeMaterial.SetFloat("_Amount", settings.Amount);
				_composeMaterial.SetFloat("_Scale", (lutSize - 1) / (1.0f * lutSize));
				_composeMaterial.SetFloat("_Offset", 1.0f / (2.0f * lutSize));
				_composeMaterial.SetFloat("_LerpBlend", settings.fLerpBlend);
				//if( IsEnabledLUTColorBlend() )
				//	Debug.LogFormat("_LerpBlend : {0}", settings.fLerpBlend);
			}


			// Setting up graySacle effect
			var isGrayScaleEnabledInSettings = settings.grayScaleEnabled;

			if (isGrayScaleEnabledInSettings && !_isGrayScaleAlreadyEnabled)
			{
				_composeMaterial.EnableKeyword(Keywords.GRAYSCALE_ON);
				_isGrayScaleAlreadyEnabled = true;
			}
			else if (!isGrayScaleEnabledInSettings && _isGrayScaleAlreadyEnabled)
			{
				_composeMaterial.DisableKeyword(Keywords.GRAYSCALE_ON);
				_isGrayScaleAlreadyEnabled = false;
			}

			if (isGrayScaleEnabledInSettings)
			{
				_composeMaterial.SetVector(Uniforms._GrayScaleData, new Vector4(settings.grayScaleRedLuminance, settings.grayScaleGreenLuminance,
					settings.grayScaleBlueLuminance, settings.grayScaleAmount));
			}

			// Setting up photoFilter effect
			var isPhotoFilterEnabledInSettings = settings.photoFilterEnabled;

			if (isPhotoFilterEnabledInSettings && !_isPhotoFilterAlreadyEnabled)
			{
				_composeMaterial.EnableKeyword(Keywords.PHOTOFILTER_ON);
				_isPhotoFilterAlreadyEnabled = true;
			}
			else if (!isPhotoFilterEnabledInSettings && _isPhotoFilterAlreadyEnabled)
			{
				_composeMaterial.DisableKeyword(Keywords.PHOTOFILTER_ON);
				_isPhotoFilterAlreadyEnabled = false;
			}

			if (isPhotoFilterEnabledInSettings)
			{
				_composeMaterial.SetColor(Uniforms._PhotoFilterRGB, settings.photoFilterColor);
				_composeMaterial.SetFloat(Uniforms._PhotoFilterDensity, settings.photoFilterDensity);
			}

			// Setting up vintage effect
			var isVintageEnabledInSettings = settings.vintageEnabled;

			if (isVintageEnabledInSettings && !_isVintageAlreadyEnabled)
			{
				_composeMaterial.EnableKeyword(Keywords.VINTAGE_ON);
				_isVintageAlreadyEnabled = true;
			}
			else if (!isVintageEnabledInSettings && _isVintageAlreadyEnabled)
			{
				_composeMaterial.DisableKeyword(Keywords.VINTAGE_ON);
				_isVintageAlreadyEnabled = false;
			}

			if (isVintageEnabledInSettings)
			{
				if (settings.vintageFilter != _currentVintageFilter)
				{
					_currentVintageFilter = settings.vintageFilter;

					if (settings.vintageFilter == VintageFilter.None)
						vintageLookupTexture = null;
					else
						vintageLookupTexture = Resources.Load<Texture2D>("Instagram/" + settings.vintageFilter.ToString());
				}
				_composeMaterial.SetTexture(Uniforms._vintageLookupTexture, vintageLookupTexture);
				_composeMaterial.SetFloat(Uniforms._VintageAmount, settings.vintageAmount);
			}


			float normalizedContrast = settings.contrast + 1f;
			float normalizedBrightness = (settings.brightness + 1f) / 2f;
			var brightnessContrastPrecomputed = (-0.5f) * (normalizedContrast + 1f) + (normalizedBrightness * 2f); // optimization
			_composeMaterial.SetVector(Uniforms._BrightnessContrast, new Vector4(normalizedContrast, normalizedBrightness, brightnessContrastPrecomputed));

			if (settings.brightnessContrastEnabled && !_isContrastAndBrightnessAlreadyEnabled)
			{
				_composeMaterial.EnableKeyword(Keywords.BRIGHTNESS_CONTRAST_ON);
				_isContrastAndBrightnessAlreadyEnabled = true;
			}
			else if (!settings.brightnessContrastEnabled && _isContrastAndBrightnessAlreadyEnabled)
			{
				_composeMaterial.DisableKeyword(Keywords.BRIGHTNESS_CONTRAST_ON);
				_isContrastAndBrightnessAlreadyEnabled = false;
			}
			_passRenderer.Blit(source, target, _composeMaterial);
		}

		private void CreateResources()
		{
			_mainCamera = GetComponent<Camera>();

			_preComposeMaterial = HelperExtensions.CreateMaterialFromShader("Sleek Render/Post Process/PreCompose");
			_composeMaterial = HelperExtensions.CreateMaterialFromShader("Sleek Render/Post Process/Compose");

			_currentCameraPixelWidth = Mathf.RoundToInt(_mainCamera.pixelWidth);
			_currentCameraPixelHeight = Mathf.RoundToInt(_mainCamera.pixelHeight);

			// Point for future main render target size changing
			int width = _currentCameraPixelWidth;
			int height = _currentCameraPixelHeight;

			// Capping max base texture height in pixels
			// We usually don't need extra pixels for precompose and blur passes
			var maxHeight = Mathf.Min(height, 720);
			var ratio = (float)maxHeight / height;

			int precomposeWidth = Mathf.RoundToInt((width * ratio) / 5f);
			int precomposeHeight = Mathf.RoundToInt((height * ratio) / 5f);

			_preComposeTexture = HelperExtensions.CreateTransientRenderTexture("Pre Compose", precomposeWidth, precomposeHeight);

			_composeMaterial.SetTexture(Uniforms._PreComposeTex, _preComposeTexture);
			_composeMaterial.SetVector(Uniforms._LuminanceConst, new Vector4(0.2126f, 0.7152f, 0.0722f, 0f));

			_isColorizeAlreadyEnabled = false;
			_isBloomAlreadyEnabled = false;
			_isVignetteAlreadyEnabled = false;
			_isContrastAndBrightnessAlreadyEnabled = false;

			_passRenderer = _passRenderer ?? new PassRenderer();

			if (_bloomRenderer != null)
			{
				_bloomRenderer.ReleaseResources();
			}

			_bloomRenderer = new DualFilterBloomRenderer(_passRenderer);

			_bloomRenderer.CreateResources(settings, _mainCamera);

			
			//if (settings.LookupTexture != null)
			//{
			//	Convert(settings.LookupTexture);
			//	previousTexture = settings.LookupTexture;
			//}
		}

		private RenderTexture CreateMainRenderTexture(int width, int height)
		{
			var isMetal = SystemInfo.graphicsDeviceType == GraphicsDeviceType.Metal;
			var isTegra = SystemInfo.graphicsDeviceName.Contains("NVIDIA");
			var rgb565NotSupported = !SystemInfo.SupportsRenderTextureFormat(RenderTextureFormat.RGB565);

			var textureFormat = RenderTextureFormat.RGB565;
			if (isMetal || isTegra || rgb565NotSupported)
			{
				textureFormat = RenderTextureFormat.ARGB32;
			}

#if UNITY_EDITOR
			textureFormat = RenderTextureFormat.ARGB32;
#endif

			var renderTexture = new RenderTexture(width, height, 16, textureFormat);
			var antialiasingSamples = QualitySettings.antiAliasing;
			renderTexture.antiAliasing = antialiasingSamples == 0 ? 1 : antialiasingSamples;
			return renderTexture;
		}

		private void ReleaseResources()
		{
			_preComposeMaterial.DestroyImmediateIfNotNull();
			_composeMaterial.DestroyImmediateIfNotNull();

			_preComposeTexture.DestroyImmediateIfNotNull();

			_bloomRenderer.ReleaseResources();

            //if (m_depthCamera)
            //    DestroyImmediate(DepthCamera);

            //if (m_depthCameraObject)
            //    DestroyImmediate(DepthCameraObject);
        }

		private void CheckSetupChangeAndRecreateResourcesIfNeeded(Camera mainCamera)
		{
			var cameraSizeHasChanged = mainCamera.pixelWidth != _currentCameraPixelWidth ||
				mainCamera.pixelHeight != _currentCameraPixelHeight;

			var someBloomSettingsHaveChanged = _bloomRenderer.SomeSettingsHaveChanged(settings);

			if (cameraSizeHasChanged || someBloomSettingsHaveChanged)
			{
				ReleaseResources();
				CreateResources();
			}
		}

		private float GetCurrentAspect(Camera mainCamera)
		{
			const float SQUARE_ASPECT_CORRECTION = 0.7f;
			return mainCamera.aspect * SQUARE_ASPECT_CORRECTION;
		}

		private void CreateDefaultSettingsIfNoneLinked()
		{
			if (settings == null)
			{
				settings = ScriptableObject.CreateInstance<SleekRenderSettings>();
				settings.name = "Default Settings";
			}
		}
	}
}