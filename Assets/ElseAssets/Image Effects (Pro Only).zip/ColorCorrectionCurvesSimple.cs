﻿using UnityEngine;
using System.Collections;

[ExecuteInEditMode]
[RequireComponent(typeof(Camera))]

public class ColorCorrectionCurvesSimple : ImageEffectBase
{
    public AnimationCurve redChannel;
	public AnimationCurve greenChannel;
    public AnimationCurve blueChannel;

    public float saturation = 1.0f;

    private Material ccMaterial;
    private Material ccInterpolationMaterial;
    private Texture2D rgbChannelTex;
    //사용하지 않아 주석처리
    //private bool updateTextures = true;
    private bool updateTexturesOnStartup = true;

    public Shader interpolationShader;
    private Texture2D prevRgbChannelTex;

    public float interpolationDelta = 0.0f;
    private float interpolationMaxDelta = 0.0f;

    void Awake()
    {
    }

    protected override void Start()
    {
        base.Start();
        updateTexturesOnStartup = true;
    }

    override protected void OnDisable()
    {
        base.OnDisable();
        if (ccMaterial != null) DestroyImmediate(ccMaterial);
        if (ccInterpolationMaterial != null) DestroyImmediate(ccInterpolationMaterial);
    }


    private bool CheckResources()
    {
        if (ccMaterial == null)
            ccMaterial = new Material(shader);
        if (ccInterpolationMaterial == null)
            ccInterpolationMaterial = new Material(interpolationShader);

        if (rgbChannelTex == null)
            rgbChannelTex = new Texture2D(256, 4, TextureFormat.ARGB32, false, true);
        if(prevRgbChannelTex == null)
            prevRgbChannelTex = new Texture2D(256, 4, TextureFormat.ARGB32, false, true);

        rgbChannelTex.hideFlags = prevRgbChannelTex.hideFlags = HideFlags.DontSave;
        rgbChannelTex.wrapMode = prevRgbChannelTex.wrapMode = TextureWrapMode.Clamp;

        if (ccMaterial.shader.isSupported == false) enabled = false;
        return ccMaterial.shader.isSupported;
    }

    private void UpdateTextures()
    {
        UpdateParameters();
    }

    public void UpdateParameters(float t = 0.0f)
    {
        CheckResources();

        // Set Preview
        Color []colors = rgbChannelTex.GetPixels();
        prevRgbChannelTex.SetPixels(colors);
        prevRgbChannelTex.Apply();

        if (redChannel != null && greenChannel != null && blueChannel != null)
        {
            for( float i=0.0f; i<=1.0f; i+= 1.0f / 255.0f)
            {
                float rCh = Mathf.Clamp(redChannel.Evaluate(i), 0.0f, 1.0f);
                float gCh = Mathf.Clamp(greenChannel.Evaluate(i), 0.0f, 1.0f);
                float bCh = Mathf.Clamp(blueChannel.Evaluate(i), 0.0f, 1.0f);

                rgbChannelTex.SetPixel((int)Mathf.Floor(i * 255.0f), 0, new Color(rCh, rCh, rCh));
                rgbChannelTex.SetPixel((int)Mathf.Floor(i * 255.0f), 1, new Color(gCh, gCh, gCh));
                rgbChannelTex.SetPixel((int)Mathf.Floor(i * 255.0f), 2, new Color(bCh, bCh, bCh));
            }

            rgbChannelTex.Apply();
        }

        interpolationDelta = interpolationMaxDelta = t;
    }

    void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if (CheckResources() == false)
        {
            Graphics.Blit(source, destination);
            return;
        }

        if (updateTexturesOnStartup)
        {
            UpdateParameters();
            updateTexturesOnStartup = false;
        }

        if (interpolationDelta > 0.0f)
        {
            ccInterpolationMaterial.SetTexture("_RgbTex", prevRgbChannelTex);
            ccInterpolationMaterial.SetTexture("_TargetRgbTex", rgbChannelTex);
            ccInterpolationMaterial.SetFloat("_Saturation", saturation);

            ccInterpolationMaterial.SetFloat("_Ratio", 1.0f - (1.0f / interpolationMaxDelta * interpolationDelta));

            Graphics.Blit(source, destination, ccInterpolationMaterial);
        }
        else {
            ccMaterial.SetTexture("_RgbTex", rgbChannelTex);
            ccMaterial.SetFloat("_Saturation", saturation);

            Graphics.Blit(source, destination, ccMaterial);
        }
    }

    void Update()
    {
        if (interpolationDelta == 0.0f) return;
        interpolationDelta -= Time.deltaTime;
        if (interpolationDelta <= 0.0f) interpolationDelta = 0.0f;
    }
}
