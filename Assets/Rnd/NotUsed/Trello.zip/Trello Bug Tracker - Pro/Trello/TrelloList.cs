namespace DG.TrelloAPI
{
    public class TrelloList
    {

        public string name = "";
        public string idBoard = "";
        public string pos = "bottom";

        public TrelloList()
        {

        }
    }
}
