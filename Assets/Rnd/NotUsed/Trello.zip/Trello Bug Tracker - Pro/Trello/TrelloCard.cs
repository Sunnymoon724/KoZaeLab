﻿namespace DG.TrelloAPI
{
	public class TrelloCard {
	
		public string name = "";
		public string desc = "";
        public string pos = "bottom";
		public string due = "null";
		public string idList = "";
		public string urlSource = "null";
		//public Texture2D image;

        public TrelloCard()
		{
			
		}		
	}
}
