﻿using UnityEngine;
using System.Collections;

namespace UnrealByte.TrelloForUnity {
	
	public class TList {

		public string name = "";
		public string idBoard = "";
		public string pos = "bottom";
		public string id = "";

		public TList() {}

	}
}
