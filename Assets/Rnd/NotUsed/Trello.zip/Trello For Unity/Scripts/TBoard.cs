﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace UnrealByte.TrelloForUnity {
	
	public class TBoard {
		
		public string name = "";
		public bool closed = false;
		public string idOrganization = "";
		public string id = "";

		public TBoard() {
			
		}		
	}
}